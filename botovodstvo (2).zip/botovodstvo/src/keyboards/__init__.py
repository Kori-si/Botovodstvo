from .defoults import commands_default_keyboard
