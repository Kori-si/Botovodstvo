from .commands import dp
from .text_answers import dp

__all__ = ['dp']